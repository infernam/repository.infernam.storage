#!/usr/bin/python
# -*- coding: utf-8 -*-

import httplib
import urllib
import urllib2
import re
import sys
import os
import Cookie
import platform
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import xbmcaddon
import httplib
import urllib
import urllib2
import base64
from datetime import date
import time
from datetime import timedelta
import re
try:
	from hashlib import md5
except:
	from md5 import md5

import sys
import os
import Cookie
import subprocess
import xbmcplugin
import xbmcgui
import xbmc
import xbmcaddon
import time
import random
import xppod
from urllib import unquote, quote




__addon__ = xbmcaddon.Addon( id = 'plugin.video.1tv.ru' )
__language__ = __addon__.getLocalizedString

addon_icon    = __addon__.getAddonInfo('icon')
addon_fanart  = __addon__.getAddonInfo('fanart')
addon_path    = __addon__.getAddonInfo('path')
addon_type    = __addon__.getAddonInfo('type')
addon_id      = __addon__.getAddonInfo('id')
addon_author  = __addon__.getAddonInfo('author')
addon_name    = __addon__.getAddonInfo('name')
addon_version = __addon__.getAddonInfo('version')

PLUGIN_ID = 'plugin.video.1tv.ru'
PLUGIN_NAME='1tv.ru'

sReferer = 'http://www.1tv.ru/'
tv1DEBUG = 0
hos = int(sys.argv[1])
show_len=50
import keyboard_ru as keyboardint

try:
	ver = sys.version_info
	ver1 = '%s.%s.%s' % (ver[0], ver[1], ver[2])
	osname = '%s %s; %s' % (os.name, sys.platform, ver1)
	pyver = platform.python_version()
	isXBMC = 'XBMC'
	if getattr(xbmc, "nonXBMC", None) is not None:
		isXBMC = 'nonXBMC'
	UA = '%s/%s (%s; %s) %s/%s 1tv.ru/%s user/%s' % (isXBMC, xbmc.getInfoLabel('System.BuildVersion').split(" ")[0], xbmc.getInfoLabel('System.BuildVersion'), osname, __addon__.getAddonInfo('id'), __addon__.getAddonInfo('version'), '0.0.1', str(uniq_id))
	xbmc.log('UA: %s' % UA)
except:
	UA = '%s/%s %s/%s/%s' % (addon_type, addon_id, urllib.quote_plus(addon_author), addon_version, urllib.quote_plus(addon_name))


#print GAcookie
#print uniq_id


try:
	import json
except ImportError:
	try:
		import simplejson as json
		xbmc.log( '[%s]: Error import json. Uses module simplejson' % addon_id, 2 )
	except ImportError:
		try:
			import demjson3 as json
			xbmc.log( '[%s]: Error import simplejson. Uses module demjson3' % addon_id, 3 )
		except ImportError:
			xbmc.log( '[%s]: Error import demjson3. Sorry.' % addon_id, 4 )

from BeautifulSoup import BeautifulSoup, BeautifulStoneSoup
import socket
socket.setdefaulttimeout(50)

Addon = xbmcaddon.Addon(id='plugin.video.1tv.ru')
icon    = Addon.getAddonInfo('icon')
siteUrl = '1tv.ru'
httpSiteUrl = 'http://' + siteUrl+'/'



def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))


def showMessage(heading, message, times = 3000, pics = addon_icon):
	try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading.encode('utf-8'), message.encode('utf-8'), times, pics.encode('utf-8')))
	except Exception, e:
		xbmc.log( '[%s]: showMessage: Transcoding UTF-8 failed [%s]' % (addon_id, e), 2 )
		try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
		except Exception, e:
			xbmc.log( '[%s]: showMessage: exec failed [%s]' % (addon_id, e), 3 )



def GET(target, post=None):
	#print target
	#print 'request:'+str(post)
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru-RU')
		req.add_header('Referer',	sReferer)
		resp = urllib2.urlopen(req)
		CE = resp.headers.get('content-encoding')
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		xbmc.log( '[%s]: GET EXCEPT [%s] [%s]' % (addon_id, e, target), 4 )
		#showMessage('HTTP ERROR', e, 5000)
		try:
			req = urllib2.Request(url = sReferer+target, data = post)
			#print 'request:'+str(post)
			req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
			#req.add_header('Host',	'1tv.ru')
			req.add_header('Accept', '*/*')
			req.add_header('Accept-Language', 'ru-RU')
			req.add_header('Referer',    sReferer)
			resp = urllib2.urlopen(req)
			CE = resp.headers.get('content-encoding')
			http = resp.read()
			resp.close()
			#print 'rsponse:'+str(http)
			return http
		except Exception, e:
			xbmc.log( '[%s]: GET EXCEPT [%s]' % (addon_id, e), 4 )
			showMessage('HTTP ERROR', e, 5000)

def mainScreen(params):
	delta1d = timedelta(days=1)
	iterday = date.today()	
	sum = 1
	for i in range(1,15):
		sum = sum + 1
		li = xbmcgui.ListItem(iterday.strftime("%a %d.%m.%Y"), addon_fanart, thumbnailImage = addon_icon)
		li.setProperty('IsPlayable', 'false')
		href = 'http://www.1tv.ru/schedule/'
		href = href + iterday.strftime("%Y-%m-%d")
		uri = construct_request({
        	'href': href,
			'title': iterday.strftime("%a %d.%m.%Y"),
			'page':1,
			'func': 'readCategory'
			})
		xbmcplugin.addDirectoryItem(hos, uri, li, True)
		iterday = iterday - delta1d
	
	xbmcplugin.endOfDirectory(hos)

def subcat(params):
	http = GET(httpSiteUrl)
	if http == None: return False
	beautifulSoup = BeautifulSoup(http)
	content = beautifulSoup.find('ul', attrs={'id': 'menu'})
	if params['sub']=='god':
		cats=content.findAll('option')
		for line in cats[1:-1]:
			title= line.string.encode('utf-8')
			href=httpSiteUrl+'select/фильмы/'+title+'/'
			if title!='None':
				li = xbmcgui.ListItem(title, addon_fanart, thumbnailImage = addon_icon)
				li.setProperty('IsPlayable', 'false')
				
				uri = construct_request({
					'href': href,
					'title':title,
					'func': 'readCategory'
				})
				xbmcplugin.addDirectoryItem(hos, uri, li, True)
	else:
		
		cats=content.findAll(href=re.compile('/%s'%params['sub']))
		list=[]
		for line in cats:
			title=None
			if line.string:
				title = str(line.string)
			else:
				title = str(line.find('strong').string)
			if title!='None':
				li = xbmcgui.ListItem(title, addon_fanart, thumbnailImage = addon_icon)
				li.setProperty('IsPlayable', 'false')
				href = line['href']
				
				uri = construct_request({
					'href': href,
					'title':title,
					'func': 'readCategory'
				})
				if href not in list:
					xbmcplugin.addDirectoryItem(hos, uri, li, True)
					list.append(href)
	xbmcplugin.endOfDirectory(hos)
	
def remove(soup, tagname):
    for tag in soup.findAll(tagname):
        contents = tag.contents
        parent = tag.parent
        tag.extract()
        for tag in contents:
            parent.append(tag)
			
def readCategory(params, postParams = None):
	#print 'read'
	fimg=None
	transnow = 0;
	transnownxt = 0;
	hasVideo = 0
	
	try:
#		hlink=params['href']+'page/'+params['page']+'/'
		hlink=params['href']+'/'
		page=params['page']
	except:
		hlink=params['href']
		page=1
	try: 
		if params['search']:
			search=True
	except:
		search=False
		
	if tv1DEBUG != 0:
		print 'hauptlink: '+str(hlink)
	http = GET(hlink)
	if http == None: return False

	beautifulSoup = BeautifulSoup(http)
 	#content = beautifulSoup.find('div', attrs={'id': 'dle-content'})
	#dataRow2 = beautifulSoup.find('section', attrs={'data-block': 'schedule_cards'})
	#print 'dataRow2: '+str(dataRow2)
	dataRows = beautifulSoup.findAll('div', attrs={'class': 'card past'})
	#print 'Length DataRows: '+str(len(dataRows))

	if len(dataRows) == 0:
		showMessage('ОШИБКА', 'Неверная страница', 3000)
		return False
	 
	for link2 in dataRows:
		if link2 != None:
			#zeit
			#print link2
			timel = '99:99' 
			link3 = link2.find('section', attrs={'class': 'time col-md-1'})
			if link3 != None:
				timel = str(link3.contents[0])
				if tv1DEBUG != 0:
					print timel
		
			#img
			link4 = link2.find('section', attrs={'class': 'body col-md-6'})
			if tv1DEBUG != 0:
				print link4
			imgsrc = ''
			href = ''
			if link4 != None:
				link7 = link2.find('section', attrs={'class': 'content hasVideo'})
				if link7 != None:
					link8 = link7.find('a', attrs={'data-role': 'card_content'})
					link9 = link8.find('div', attrs={'class': 'image col-md-2'})
					link10 = link9.find('div', attrs={'class': 'border'})
					imgdiv = link10.find('div', attrs={'class': 'wrapper'})
					if imgdiv != None:
						imgsrc = imgdiv.find('img')['src']
					hasVideo = 1
					#href
					if link8 != None:
						href = link8['href']
					
				else:
					link7 = link2.find('section', attrs={'class': 'content'})
					if link7 != None:
						link8 = link7.find('a', attrs={'data-role': 'card_content'})
						link9 = link8.find('div', attrs={'class': 'image col-md-2'})
						link10 = link9.find('div', attrs={'class': 'border'})
						imgdiv = link10.find('div', attrs={'class': 'wrapper'})
						if imgdiv != None:
							imgsrc = imgdiv.find('img')['src']
						else:
							imgdiv = link10.find('div', attrs={'class': 'themed-wrapper theme-red'})
							if imgdiv != None:
								imgsrc = imgdiv.find('img')['src']							
						#href
						try:
							if link8 != None:
								href = link8['href']
						except: pass	
			#title
			title = 'Kein Title gefunden'
			if link4 != None:
				link5 = link4.find('a', attrs={'class': 'title'})
				if link5 != None:				
					link6 = link5.b
					remove(link6,'a')
					remove(link6,'b')
					remove(link6,'span')				
					title = str(link6).replace('<b>','').replace('</b>','')
					if tv1DEBUG != 0:
						print title
			if href != '':
				href = sReferer + href
			if tv1DEBUG != 0:
				print 'href' + str(href)
			title = timel + ' - ' + title
			#if hasVideo != 0:
			#	coltitle = '%s' % title
			#else:
			#	coltitle = '[COLOR green]%s[/COLOR]' % title
			coltitle = title
			imgsrc = 'http:' + imgsrc
			if tv1DEBUG != 0:
				print imgsrc
			li=xbmcgui.ListItem(coltitle, addon_icon,thumbnailImage=imgsrc)    		
			li.setInfo(type='video', infoLabels = {'plot':None})
			li.setProperty('IsPlayable', 'false')					
			
			try:
				uri = construct_request({
            				'title': title,
                            'href': href,
                            'func': 'readFileVid',
                            'page': href,
                            'src': imgsrc
                            })
				xbmcplugin.addDirectoryItem(hos, uri, li, True)
			except:
				uri = construct_request({
                            'title': title,
                            'href': href,
                            'func': 'readFileVid',
                            'page': href,
                            'src': imgsrc
                            })
				xbmcplugin.addDirectoryItem(hos, uri, li, True)
	
	#try:
	
	

	xbmc.executebuiltin('Container.SetViewMode(500)')
	xbmcplugin.endOfDirectory(hos)


def readFileVid(params):
	http = None
	try:
		shref = params['href']	
		http = GET(shref)		
	except: pass
	
	
	
	if http == None: return False
	beautifulSoup = BeautifulSoup(http)
	tvp1 = beautifulSoup.find('div', attrs={'class': 'tv1player'})
	pllisturl = tvp1['data-playlist-url']
	if tv1DEBUG != 0:
		print 'pllisturl ' + str(pllisturl)
	
	jsonpll = GET(sReferer + pllisturl[1:])	
	if tv1DEBUG != 0:
		print 'jsonpll ' + str(jsonpll)
	jsjson = json.loads(jsonpll)
	
	dataRows = jsjson

	
	if len(dataRows) == 0:
		showMessage('ОШИБКА', 'Поток отсутствует', 3100)
		return False
		
	for dr in dataRows:
		try:
			flname = 'http:' + dr['mbr'][0]['src']
			tit = str(dr['title'].encode('utf-8'))			
			imgsrc = 'http:' + str(dr['poster_thumb'])

			if tv1DEBUG != 0:
				print 'flname' + str(flname)	
			
			li = xbmcgui.ListItem(tit, addon_icon, thumbnailImage = imgsrc)
			li.setProperty('IsPlayable','true')
			uri = construct_request({
							'func': 'play',
							'file': flname
							})
			xbmcplugin.addDirectoryItem(hos, uri, li, False)
		except: pass
	xbmcplugin.endOfDirectory(hos)
            
def readFile(params):
	http = GET(params['href'])
	#print 'http'+str(http)
	if http == None: return False
	beautifulSoup = BeautifulSoup(http)
	content = beautifulSoup.find('param', attrs={'name': 'flashvars'})
	#print content
	findfile=str(content)
	#print 'findfile'+findfile
	pat=re.compile('le=.+"', re.S)
	pat_pl=re.compile('pl=.+"', re.S)
	pat_st=re.compile('st=.+"', re.S)
	mfil = pat.findall(findfile)
	pfil = pat_pl.findall(findfile)
	stfile = pat_st.findall(findfile)
	#print 'pfil'+pfil
	flname=None
	if mfil: 
		#print 'mfile30:'+mfil[0][3:-1]
		flname=mfil[0][3:-1]
		#flname=xppod.Decode(mfil[0][3:-1])
		#print 'flname:'+flname
	if pfil: 
		#print pfil[0][3:-1]
		#flname=xppod.Decode(pfil[0][3:-1])
		#print 'mfile30:'+pfil[0][3:-1]
		flname=pfil[0][3:-1]
	if stfile: 
		#print pfil[0][3:-1]
		#flname=xppod.Decode(pfil[0][3:-1])
		#print 'mfile30:'+stfile[0][3:-1]
		flname=stfile[0][3:-1]
		#print 'flname:'+flname
	if mfil: 
		#print 'play file ' + mfil[0]
		try:	
			li = xbmcgui.ListItem(params['title'], addon_icon, thumbnailImage = params['src'])
		except: 
			li = xbmcgui.ListItem(params['title'], addon_icon, thumbnailImage = addon_icon)
		li.setProperty('IsPlayable', 'true')
		#print 'mfil0: '+xppod.Decode(lurl.split('=')[1])
		uri = construct_request({
			'func': 'play',
			'file': flname
			})
		#print 'uri for addDir: '+uri
		xbmcplugin.addDirectoryItem(hos, uri, li, False)
	elif pfil: 
		#print 'playlist in ' + lurl.split('=')[1]
		http=flname
		#print 'after xppod: '+str(http)
		http = GET(http)
		#print 'http pl='+str(http)
		f=http.find('{')
		f1=0
		f1=http.rfind('}]}]}{');
		#print 'http' + http
		try:
			http= xppod.Decode(str(http).strip())
		except:
			pat=re.compile('[\w\d=.,+]+', re.S)
			http = pat.findall(http)[0]
			#print 'http after xpod:' + str(http.encode('utf-8'))
		try:
			jsdata=json.loads(str(http),'iso-8859-1')
		except:
			jsdata=json.loads(http)
		has_sesons=False
		#print 'json data:' + str(jsdata)
		playlist = jsdata['playlist']
		#print 'playlist' + str(playlist.encode('utf-8'))
		for file in playlist:
			#print 'file: '+str(file.encode('utf-8'))
			tt= 'aaa'
			tt=tt.encode("latin-1","ignore")
			l=''
			try:
				li = xbmcgui.ListItem(tt, addon_icon, thumbnailImage = params['src'])
				li.setProperty('IsPlayable', 'true')
				uri = construct_request({
					'func': 'play',
					'file': file['file']
					})
				#print 'uri for addDir: '+ str(uri)
				xbmcplugin.addDirectoryItem(hos, uri, li, False)
			except: pass
			try:
				for t in file['playlist']:
					#print t
					li = xbmcgui.ListItem(t['comment'].encode("latin-1","ignore"), addon_icon, thumbnailImage = params['src'])
					li.setProperty('IsPlayable', 'true')
					uri = construct_request({
						'func': 'play',
						'file': t['file']
						})
					#print 'uri for addDir: '+ str(uri)
					has_sesons=True
					xbmcplugin.addDirectoryItem(hos, uri, li, False)
				if has_sesons==False:
					li = xbmcgui.ListItem(file['comment'].encode("latin-1","ignore"), addon_icon, thumbnailImage = params['src'])
					li.setProperty('IsPlayable', 'true')
					uri = construct_request({
						'func': 'play',
						'file': file['file']
						})
					#print 'uri for addDir: '+ str(uri)
					xbmcplugin.addDirectoryItem(hos, uri, li, False)
			except: pass
	else:
		#print 'stfile'
		#print 'playlist in ' + lurl.split('=')[1]
		http=flname
		#print 'http: '+str(http)
		if http == None: return False
		http = GET(http)
		#print 'http pl='+str(http).strip()
		#print 'http2' + http
		try:
			http= xppod.Decode(str(http).strip())
			#print 'http after xpod:' + str(http.encode('utf-8'))
		except:
			pat=re.compile('[\w\d=.,+]+', re.S)
			http = pat.findall(http)[0]
		try:
			jsdata=json.loads(str(http),'iso-8859-1')
		except:
			jsdata=json.loads(http)
		has_sesons=False
		#print 'json data:' + str(jsdata)
		if 'pl' in jsdata:
			playlist = jsdata['pl'].replace('\'','"')
			playlist = json.loads(playlist, 'utf-8')
			playlist = playlist['playlist']
			for file in playlist:
				if 'file' in file:
					try:
						#print 'file: '+str(file['file'])
						tt= file['comment'].encode('latin-1',"ignore"),
						l=''
						li = xbmcgui.ListItem(tt, addon_icon, thumbnailImage = params['src'])
						li.setProperty('IsPlayable', 'true')
						uri = construct_request({
							'func': 'play',
							'file': file['file']
							})
						#print 'uri for addDir: '+ str(uri)
						xbmcplugin.addDirectoryItem(hos, uri, li, False)
					except: pass
				else:
					try:
						for t in file['playlist']:
							#print t
							if 'file' in t:
								li = xbmcgui.ListItem(t['comment'].encode('latin-1',"ignore"), addon_icon, thumbnailImage = params['src'])
								li.setProperty('IsPlayable', 'true')
								uri = construct_request({
									'func': 'play',
									'file': t['file']
									})
								#print 'uri for addDir: '+ str(uri)
								has_sesons=True
								xbmcplugin.addDirectoryItem(hos, uri, li, False)
							else:
								for t2 in t['playlist']:
									#print t2
									li = xbmcgui.ListItem(t2['comment'].encode('latin-1',"ignore"), addon_icon, thumbnailImage = params['src'])
									li.setProperty('IsPlayable', 'true')
									uri = construct_request({
										'func': 'play',
										'file': t2['file']
										})
									#print 'uri for addDir: '+ str(uri)
									has_sesons=True
									xbmcplugin.addDirectoryItem(hos, uri, li, False)
									if has_sesons==False:
										li = xbmcgui.ListItem(t['comment'].encode('latin-1',"ignore"), addon_icon, thumbnailImage = params['src'])
										li.setProperty('IsPlayable', 'true')
										uri = construct_request({
											'func': 'play',
											'file': t['file']
											})
										#print 'uri for addDir: '+ str(uri)
										xbmcplugin.addDirectoryItem(hos, uri, li, False)
						if has_sesons==False:
							li = xbmcgui.ListItem(file['comment'].encode('latin-1',"ignore"), addon_icon, thumbnailImage = params['src'])
							li.setProperty('IsPlayable', 'true')
							uri = construct_request({
								'func': 'play',
								'file': file['file']
								})
							#print 'uri for addDir: '+ str(uri)
							xbmcplugin.addDirectoryItem(hos, uri, li, False)
					except: pass
		else:
			li = xbmcgui.ListItem(params['title'], addon_icon, thumbnailImage = params['src'])
			li.setProperty('IsPlayable', 'true')
			uri = construct_request({
				'func': 'play',
				'file': jsdata['file']
				})
			#print 'uri for addDir: '+ str(uri)
			xbmcplugin.addDirectoryItem(hos, uri, li, False)
	xbmcplugin.endOfDirectory(hos)

	
def geturl(url):
	f = None
	url=url[1:len(url)]
	myhttp = 'http://fcsd.tv/ru/xmlinfo/?idv=%s' % url
	http = GET('http://fcsd.tv/ru/xmlinfo/?idv=%s' % url)
	if http == None: return False
	beautifulSoup = BeautifulSoup(http)
	furl=beautifulSoup.find('video')
	f=furl.find('hq')
	if not f: f=furl.find('rq')
	return f['url']

def play(params):

	i = xbmcgui.ListItem(path = params['file'])
	xbmcplugin.setResolvedUrl(hos, True, i)
	
def get_params(paramstring):
	param=[]
	if len(paramstring)>=2:
		params=paramstring
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	if len(param) > 0:
		for cur in param:
			param[cur] = urllib.unquote_plus(param[cur])
	return param


def addon_main():
	params = get_params(sys.argv[2])
	try:
		func = params['func']
		del params['func']
	except:
		func = None
		xbmc.log( '[%s]: Primary input' % addon_id, 1 )
		mainScreen(params)
	if func != None:
		try: pfunc = globals()[func]
		except:
			pfunc = None
			xbmc.log( '[%s]: Function "%s" not found' % (addon_id, func), 4 )
			showMessage('Internal addon error', 'Function "%s" not found' % func, 2000)
		if pfunc: pfunc(params)
